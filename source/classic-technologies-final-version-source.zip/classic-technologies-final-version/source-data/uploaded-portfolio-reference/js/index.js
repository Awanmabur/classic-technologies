
 
        /* ==========================
           Helpers
        ========================== */
        console.log("✅ NEW index.js loaded", new Date().toISOString());

        const $ = (q, el = document) => el.querySelector(q);
        const $$ = (q, el = document) => Array.from(el.querySelectorAll(q));

        const FALLBACK_IMG =
            'data:image/svg+xml;utf8,' +
            encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#05528d"/>
            <stop offset="0.55" stop-color="#0b6fb5"/>
            <stop offset="1" stop-color="#22c55e"/>
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="#070a14"/>
        <rect x="0" y="0" width="1200" height="700" fill="url(#g)" opacity="0.22"/>
        <circle cx="220" cy="160" r="110" fill="url(#g)" opacity="0.35"/>
        <circle cx="980" cy="520" r="160" fill="url(#g)" opacity="0.25"/>
        <rect x="70" y="420" width="1060" height="160" rx="28" fill="rgba(255,255,255,0.10)" stroke="rgba(255,255,255,0.16)"/>
        <text x="110" y="485" fill="rgba(255,255,255,0.92)" font-family="Inter, Arial" font-size="44" font-weight="800">Project Preview</text>
        <text x="110" y="535" fill="rgba(255,255,255,0.70)" font-family="Inter, Arial" font-size="26">Image unavailable — showing fallback</text>
      </svg>
    `);

        function safeArr(v) { return Array.isArray(v) ? v : []; }
        function getParam(name) {
            try {
                const u = new URL(location.href);
                return u.searchParams.get(name);
            } catch (e) { return null; }
        }

        /* ==========================
           Reveal fallback (IMPORTANT)
           ✅ Fix "some parts not showing on phone" when IntersectionObserver fails.
        ========================== */
        function forceShowAllReveal() {
            $$(".reveal").forEach(el => el.classList.add("show"));
        }

        /* ==========================
           Smoove helpers
        ========================== */
        function attrsFrom(obj = {}) {
            return Object.entries(obj).map(([k, v]) => `${k}="${String(v).replace(/"/g, "&quot;")}"`).join(" ");
        }
        function setAttrs(el, obj = {}) {
            if (!el) return;
            for (const [k, v] of Object.entries(obj)) el.setAttribute(k, v);
        }

        /* ==========================
           KPI / Services / Stack / Testimonials
        ========================== */
        const kpis = [
            { n: "8+ yrs", l: "Experience" },
            { n: "30+", l: "Projects shipped" },
            { n: "Node + React", l: "Main stack" },
            { n: "Fast + Secure", l: "Build quality" },
            { n: "Global", l: "Remote-ready" },
            { n: "East Africa", l: "Local impact" }
        ];

        const services = [
            { icon: "fa-wand-magic-sparkles", title: "Premium UI/UX Websites", desc: "High-converting websites with modern design, animations, and strong SEO." },
            { icon: "fa-server", title: "Backend & APIs", desc: "Secure APIs, authentication, integrations, and scalable architecture." },
            { icon: "fa-bag-shopping", title: "E-commerce Builds", desc: "Catalog, payments, orders, and admin dashboards — optimized for sales." },
            { icon: "fa-shield-halved", title: "Security & Performance", desc: "Hardening, validation, monitoring basics, and speed improvements." },
            { icon: "fa-diagram-project", title: "SaaS Platforms", desc: "Multi-tenant systems, roles, billing, and scalable product foundations." },
            { icon: "fa-cloud-arrow-up", title: "Deployment & Domains", desc: "Heroku/Render/VPS setup, SSL, DNS, redirects, and production checks." }
        ];

        const stack = {
            core: ["Node.js", "Express", "React", "MongoDB", "REST APIs", "JWT/Auth", "HTML/CSS", "JavaScript"],
            tools: ["Git/GitHub", "Cloudinary", "Postman", "CI/CD basics", "Docker (basic)", "Nginx (basic)"],
            focus: ["Performance", "SEO", "Security", "Clean UI", "Scalable architecture", "Maintainable code"]
        };

        const testimonials = [
            { quote: "Simon delivered a clean, modern product with strong communication and great speed.", name: "Client Feedback", role: "Founder / CEO", img: "https://images.unsplash.com/photo-1502685104226-ee32379fefbe?auto=format&fit=crop&w=400&q=70" },
            { quote: "Reliable and professional — everything worked smoothly in production.", name: "Client Feedback", role: "Business Owner", img: "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=70" },
            { quote: "Great problem-solving and quality delivery. Highly recommended.", name: "Client Feedback", role: "Product Lead", img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=70" }
        ];

        /* ==========================
           Projects
        ========================== */
        const projects = {
            "classic-events-pro": {
                title: "Classic Events Pro (Event Management & Ticketing)",
                desc: "A premium event platform with organizer tools, promoter tracking, ticketing, QR check-in, and admin controls — built end-to-end for production use.",
                tags: ["Events", "Ticketing", "Promoters", "Admin", "Analytics"],
                img: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1400&q=80",
                live: "https://classicpro.events",
                code: "https://github.com/Awanmabur/classic-events",
                roles: [
                    { icon: "fa-solid fa-code", title: "Full-Stack Ownership", points: ["Designed and built the system end-to-end", "UI/UX, backend, database, and integrations", "Production-first architecture decisions"] },
                    { icon: "fa-solid fa-diagram-project", title: "System Architecture", points: ["Modular controllers + clean routing", "Scalable patterns for events/tickets/orders", "Admin tools and permissions structure"] },
                    { icon: "fa-solid fa-users-gear", title: "Roles & Dashboards", points: ["Organizer dashboard (events, tickets, sales)", "Promoter dashboard (links, sales, earnings)", "Admin moderation & approvals"] },
                    { icon: "fa-solid fa-credit-card", title: "Payments + Orders", points: ["Checkout and order records", "Receipts and status tracking", "Refund-ready structure and reconciliation"] },
                    { icon: "fa-solid fa-qrcode", title: "Ticket QR + Check-in", points: ["QR generation per ticket", "Validation flow for entry scanning", "Anti-fraud checks + status updates"] },
                    { icon: "fa-solid fa-shield-halved", title: "Security & Hardening", points: ["Validation & safe input handling", "Rate limiting and safe auth patterns", "Audit-friendly logs and error handling"] }
                ],
                features: [
                    { icon: "fa-solid fa-calendar-check", title: "Event Creation & Publishing", desc: "Create events, sessions, ticket types, capacity rules, visibility, schedules, and promo logic." },
                    { icon: "fa-solid fa-ticket", title: "Ticketing & Orders", desc: "Ticket categories, pricing tiers, buyer details, order confirmation, and receipt-ready structure." },
                    { icon: "fa-solid fa-users", title: "Promoter System", desc: "Share links, ref codes, attribution, earnings calculation, payouts-ready records and reporting." },
                    { icon: "fa-solid fa-qrcode", title: "QR Tickets + Gate Validation", desc: "QR ticket generation and entry verification workflow with unique IDs and validation state." },
                    { icon: "fa-solid fa-clipboard-check", title: "Admin Moderation Tools", desc: "Approve events, edit requests, manage users/promoters, and enforce platform rules." },
                    { icon: "fa-solid fa-chart-line", title: "Analytics & Performance", desc: "Sales insights, event trends, promoter performance, and peak-day reliability improvements." }
                ],
                challenges: [
                    {
                        title: "Problem: Promoter attribution accuracy",
                        lines: [
                            { type: "fix", text: "Solution: consistent query params + server-side attribution checks on checkout/order creation." },
                            { type: "good", text: "Result: reliable promoter reporting and fewer mis-attributions." }
                        ]
                    },
                    {
                        title: "Problem: Peak traffic on event day",
                        lines: [
                            { type: "fix", text: "Solution: optimized pages, reduced payloads, safe caching patterns, and controlled DB queries." },
                            { type: "good", text: "Result: stable performance under heavy load." }
                        ]
                    }
                ]
            },
            "classic-trip": {
                title: "Classic Trip (Travel Booking & Ticketing)",
                desc: "A premium booking system for bus/train/flights/hotels with operator dashboards, schedules, inventory, tickets, and promoter/affiliate tracking.",
                tags: ["Booking", "Tickets", "Inventory", "Promoters", "Admin"],
                img: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=1400&q=80",
                live: "https://awanmabur.github.io/classic-trip",
                code: "https://github.com/Awanmabur/classic-trip",
                roles: [
                    { icon: "fa-solid fa-code", title: "Full-Stack Build From Scratch", points: ["Built frontend and backend end-to-end", "Designed booking logic + operator workflows", "Implemented reusable UI components"] },
                    { icon: "fa-solid fa-sitemap", title: "Booking Architecture", points: ["Unified booking model for multiple providers", "Reservation → confirmation lifecycle", "Extensible provider integration pattern"] },
                    { icon: "fa-solid fa-calendar-days", title: "Schedules & Availability", points: ["Schedule creation and seat/room slots", "Availability checks + locking patterns", "Admin/operator controls"] },
                    { icon: "fa-solid fa-user-shield", title: "Auth + Roles", points: ["Customer accounts & history", "Operator dashboards & permissions", "Admin oversight patterns"] },
                    { icon: "fa-solid fa-users", title: "Promoters / Affiliate Tracking", points: ["Referral links and attribution", "Commission-ready accounting logs", "Promo performance reporting"] },
                    { icon: "fa-solid fa-shield-halved", title: "Production Quality", points: ["Validation + security checks", "Error handling + logging", "Performance-first data access"] }
                ],
                features: [
                    { icon: "fa-solid fa-magnifying-glass", title: "Search & Filters", desc: "Routes, dates, pricing, class/type, and availability filters in a clean booking UI." },
                    { icon: "fa-solid fa-ticket", title: "Tickets & Booking References", desc: "Booking reference IDs, confirmation flows, and receipt-ready records." },
                    { icon: "fa-solid fa-layer-group", title: "Multi-Provider Booking", desc: "Bus/train/flight/hotel structure designed to scale and add providers easily." },
                    { icon: "fa-solid fa-building", title: "Operator Dashboard", desc: "Manage schedules, inventory, pricing, and view sales/booking reports." },
                    { icon: "fa-solid fa-users", title: "Promoters / Referrals", desc: "Share links, attribution on checkout, and promoter reporting & earnings structure." },
                    { icon: "fa-solid fa-chart-line", title: "Reports & Admin Controls", desc: "Operational insights, booking trends, and admin moderation patterns." }
                ],
                challenges: [
                    {
                        title: "Problem: Avoiding overbooking",
                        lines: [
                            { type: "fix", text: "Solution: availability locking + confirmation steps with controlled inventory updates." },
                            { type: "good", text: "Result: fewer conflicts and reliable seat/room allocation." }
                        ]
                    },
                    {
                        title: "Problem: Multiple provider flow complexity",
                        lines: [
                            { type: "fix", text: "Solution: a single booking lifecycle with provider-specific metadata and adapters." },
                            { type: "good", text: "Result: easier scaling to new transport/hotel partners." }
                        ]
                    }
                ]
            },
            "classic-education-suite": {
                title: "Classic Education Suite (Multi-Tenant SaaS)",
                desc: "A premium education SaaS built for universities and schools: admissions, portals, finance-ready structure, LMS-ready patterns, analytics, and a School Profiles Directory listing institutions and services.",
                tags: ["SaaS", "Education", "Multi-tenant", "Portals", "School Profiles"],
                img: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1400&q=80",
                live: "",
                code: "",
                roles: [
                    { icon: "fa-solid fa-code", title: "Full-Stack SaaS Delivery", points: ["Built tenant-ready platform end-to-end", "Frontend UX + backend logic + data layer", "Reusable components and clean UI patterns"] },
                    { icon: "fa-solid fa-diagram-project", title: "Multi-Tenancy & Isolation", points: ["Tenant routing + branding hooks", "Clean boundaries per institution", "Scalable onboarding structure"] },
                    { icon: "fa-solid fa-users-gear", title: "Role-Based Portals (RBAC)", points: ["Student/Staff/Lecturer/Admin portals", "Permission-controlled menus and actions", "Safe admin operations"] },
                    { icon: "fa-solid fa-file-signature", title: "Admissions Workflows", points: ["Online applications + review", "Approval → enrollment flows", "Audit-friendly status transitions"] },
                    { icon: "fa-solid fa-shield-halved", title: "Security & Data Integrity", points: ["Validation rules + safe inputs", "Consistent schemas and constraints", "Logs + error handling patterns"] },
                    { icon: "fa-solid fa-chart-column", title: "Analytics Foundation", points: ["Dashboards and reporting hooks", "Institution-level metrics", "Growth-ready architecture"] }
                ],
                features: [
                    { icon: "fa-solid fa-building-columns", title: "Multi-Tenant Institutions", desc: "Tenant setup, branding, configurations and scalable onboarding patterns per school/university." },
                    { icon: "fa-solid fa-user-graduate", title: "Admissions + Enrollment", desc: "Online application forms, review pipeline, approvals, and student onboarding flows." },
                    { icon: "fa-solid fa-users-gear", title: "Role Portals (RBAC)", desc: "Students, lecturers, staff, finance/admin portals with permission-based experiences." },
                    { icon: "fa-solid fa-id-card", title: "Student Records & Services", desc: "Profiles, documents, requests, department structures, and service workflows." },
                    { icon: "fa-solid fa-school", title: "School Profiles Directory", desc: "A directory listing schools/universities with public profiles, programs/services, and discovery UX." },
                    { icon: "fa-solid fa-chart-line", title: "Reports & Analytics", desc: "Dashboards for operations, admissions insights, and reporting-ready architecture." }
                ],
                challenges: [
                    {
                        title: "Problem: Strong tenant separation",
                        lines: [
                            { type: "fix", text: "Solution: tenant-aware routing and tenant configuration boundaries across the system." },
                            { type: "good", text: "Result: safer isolation and easier onboarding of new institutions." }
                        ]
                    },
                    {
                        title: "Problem: Complex roles and permissions",
                        lines: [
                            { type: "fix", text: "Solution: structured RBAC with clear portal views and admin-controlled privileges." },
                            { type: "good", text: "Result: fewer permission bugs and smoother UX per role." }
                        ]
                    }
                ]
            },
            "classic-mart": {
                title: "Classic Mart (E-commerce Platform)",
                desc: "A premium e-commerce platform with catalog, cart, checkout, orders, admin tools, and SEO-focused structure.",
                tags: ["E-commerce", "Payments", "Orders", "SEO", "Admin"],
                img: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1400&q=80",
                live: "https://awanmabur.github.io/classicmart/",
                code: "https://github.com/Awanmabur/classicmart",
                roles: [
                    { icon: "fa-solid fa-code", title: "Full-Stack Build", points: ["Built storefront + admin from scratch", "Backend APIs and DB models", "Checkout and order lifecycle"] },
                    { icon: "fa-solid fa-cart-shopping", title: "Storefront UX", points: ["Product pages", "Cart UX", "Search/filter structure"] },
                    { icon: "fa-solid fa-box", title: "Orders & Inventory", points: ["Order statuses and tracking", "Stock control patterns", "Admin operations"] },
                    { icon: "fa-solid fa-credit-card", title: "Checkout & Payments", points: ["Payment-ready architecture", "Receipt records", "Conversion-friendly flows"] },
                    { icon: "fa-solid fa-magnifying-glass", title: "SEO & Performance", points: ["SEO-first page structure", "Optimized assets patterns", "Fast browsing UX"] },
                    { icon: "fa-solid fa-shield-halved", title: "Security & Stability", points: ["Validation and safe inputs", "Auth/account security patterns", "Error handling and logs"] }
                ],
                features: [
                    { icon: "fa-solid fa-layer-group", title: "Product Catalog", desc: "Categories, product variants, pricing, images, and SEO-ready product pages." },
                    { icon: "fa-solid fa-cart-shopping", title: "Cart & Checkout", desc: "Cart persistence, checkout flow, totals calculations, and order creation." },
                    { icon: "fa-solid fa-receipt", title: "Orders & Receipts", desc: "Order confirmation, buyer records, receipts and order status lifecycle." },
                    { icon: "fa-solid fa-boxes-stacked", title: "Inventory Patterns", desc: "Stock tracking structures, admin adjustments, and low-stock readiness." },
                    { icon: "fa-solid fa-user", title: "Customer Accounts", desc: "Profiles, addresses, order history and account management structure." },
                    { icon: "fa-solid fa-chart-line", title: "Admin Reports", desc: "Sales trends, product insights and management dashboards foundation." }
                ],
                challenges: [
                    { title: "Problem: Checkout drop-offs", lines: [{ type: "fix", text: "Solution: simplified checkout steps and stronger CTA flow design." }, { type: "good", text: "Result: improved conversion and less friction." }] },
                    { title: "Problem: Admin daily operations complexity", lines: [{ type: "fix", text: "Solution: clean admin screens and consistent management components." }, { type: "good", text: "Result: faster operations and fewer errors." }] }
                ]
            },
            "juba-rentals": {
                title: "Juba Rentals (Real Estate & Vehicles Marketplace)",
                desc: "A premium listings platform for cars, houses and land with verification workflows, agent tools, and inquiry/lead management.",
                tags: ["Marketplace", "Real Estate", "Vehicles", "Leads", "Admin"],
                img: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1400&q=80",
                live: "https://awanmabur.github.io/jubarentals/",
                code: "https://github.com/Awanmabur/jubarentals"
            },
            "chariot-technologies": {
                title: "Chariot Technologies (Mobility Platform)",
                desc: "A premium mobility platform connecting riders and drivers with safety patterns, scalable backend design, and ops dashboards foundation.",
                tags: ["Mobility", "Platform", "SaaS", "Safety", "Ops"],
                img: "https://images.unsplash.com/photo-1526662092594-e98c1e356d6a?auto=format&fit=crop&w=1400&q=80",
                live: "https://www.chariot.ug",
                code: "https://github.com/Chariot-Technologies/chariot-technologies"
            }
        };

        const featuredWork = [
            { id: "classic-events-pro", title: "Classic Events Pro", desc: projects["classic-events-pro"].desc, tags: ["Platform", "Tickets", "Promoters"], live: projects["classic-events-pro"].live, code: projects["classic-events-pro"].code, img: projects["classic-events-pro"].img },
            { id: "classic-mart", title: "Classic Mart", desc: projects["classic-mart"].desc, tags: ["E-commerce", "Payments", "SEO"], live: projects["classic-mart"].live, code: projects["classic-mart"].code, img: projects["classic-mart"].img },
            { id: "chariot-technologies", title: "Chariot Technologies", desc: projects["chariot-technologies"].desc, tags: ["Platform", "Mobility", "SaaS"], live: projects["chariot-technologies"].live, code: projects["chariot-technologies"].code, img: projects["chariot-technologies"].img },
            { id: "classic-education-suite", title: "Classic Education Suite", desc: projects["classic-education-suite"].desc, tags: ["SaaS", "Education", "Multi-tenant"], live: projects["classic-education-suite"].live, code: projects["classic-education-suite"].code, img: projects["classic-education-suite"].img },
            { id: "classic-trip", title: "Classic Trip", desc: projects["classic-trip"].desc, tags: ["Booking", "Tickets", "Promoters"], live: projects["classic-trip"].live, code: projects["classic-trip"].code, img: projects["classic-trip"].img },
            { id: "juba-rentals", title: "Juba Rentals", desc: projects["juba-rentals"].desc, tags: ["Marketplace", "Real Estate", "Leads"], live: projects["juba-rentals"].live, code: projects["juba-rentals"].code, img: projects["juba-rentals"].img }
        ];

        /* ==========================
           Smoove effect maps
        ========================== */
        const KPI_SMOOVE = [
            { "data-move-y": "60px", "data-move-z": "-100px" },
            { "data-move-y": "90px", "data-rotate-z": "-12deg", "data-move-z": "-220px" },
            { "data-move-y": "75px", "data-rotate-z": "10deg", "data-move-z": "-240px" },
            { "data-move-y": "95px", "data-rotate-x": "10deg", "data-move-z": "-260px" },
            { "data-move-y": "65px", "data-rotate-y": "10deg", "data-move-z": "-240px" },
            { "data-move-y": "85px", "data-rotate-y": "-10deg", "data-move-z": "-240px" },
        ];

        const HERO_MINICARD_SMOOVE = [
            { "data-move-y": "80px", "data-move-z": "-280px", "data-rotate-x": "70deg" },
            { "data-move-x": "180px", "data-move-z": "-240px", "data-rotate-y": "-70deg" },
            { "data-move-y": "120px", "data-move-z": "-300px", "data-rotate-x": "80deg" },
            { "data-move-x": "-180px", "data-move-z": "-240px", "data-rotate-y": "70deg" },
        ];

        const STACK_SMOOVE = [
            { "data-rotate-y": "90deg", "data-move-x": "-200px", "data-move-z": "-240px" },
            { "data-rotate-x": "70deg", "data-move-y": "180px", "data-move-z": "-260px" },
            { "data-scale": "0.6", "data-move-y": "120px", "data-move-z": "-220px" },
        ];

        const TESTIMONIAL_SMOOVE = [
            { "data-rotate-y": "90deg", "data-move-x": "-240px", "data-move-z": "-260px" },
            { "data-scale": "0.7", "data-rotate-x": "65deg", "data-move-y": "140px" },
        ];

        const CONTACT_SMOOVE = [
            { "data-move-y": "120px", "data-move-z": "-260px" },
            { "data-rotate-y": "80deg", "data-move-x": "220px", "data-move-z": "-280px" },
        ];

        const FOOTER_SMOOVE = [
            { "data-move-y": "80px", "data-move-z": "-200px" },
            { "data-rotate-y": "70deg", "data-move-x": "-140px", "data-move-z": "-240px" },
            { "data-rotate-y": "-70deg", "data-move-x": "140px", "data-move-z": "-240px" },
            { "data-rotate-x": "65deg", "data-move-y": "120px", "data-move-z": "-220px" },
        ];

        const SERVICE_SMOOVE = [
            { "data-rotate-x": "180deg", "data-move-z": "-500px", "data-move-y": "1200px" },
            { "data-rotate-x": "90deg", "data-move-z": "-300px", "data-move-x": "500px" },
            { "data-rotate-x": "90deg", "data-move-z": "-500px", "data-move-y": "200px" },
            { "data-rotate-y": "270deg", "data-move-x": "-150%", "data-move-z": "-200px" },
            { "data-rotate-y": "270deg", "data-move-x": "150%", "data-rotate-x": "180deg", "data-move-z": "-700px" },
            { "data-rotate-y": "180deg", "data-move-z": "-200px", "data-move-x": "-300px" },
        ];

        const PROJECT_SMOOVE = [
            { "data-scale": "5" },
            { "data-scale": "0", "data-skew": "90deg,90deg" },
            { "data-rotate-x": "90deg", "data-move-z": "-500px", "data-move-y": "200px" },
            { "data-rotate-y": "180deg", "data-move-z": "-200px", "data-move-x": "-300px" },
            { "data-rotate-x": "180deg", "data-rotate-y": "180deg", "data-move-z": "-700px" },
            { "data-rotate-y": "180deg", "data-move-z": "-100px", "data-move-x": "500px" },
        ];

        /* ==========================
           Render sections
        ========================== */
        function renderKPIs() {
            const el = $("#kpis");
            if (!el) return;
            el.innerHTML = kpis.map((k, idx) => `
        <div class="kpi kpi-anim" ${attrsFrom(KPI_SMOOVE[idx % KPI_SMOOVE.length])}>
          <div class="n">${k.n}</div><div class="l">${k.l}</div>
        </div>
      `).join("");
        }

        function renderWork() {
            const el = $("#workGrid");
            if (!el) return;
            el.innerHTML = featuredWork.map((w, idx) => `
        <article class="work reveal project-card" ${attrsFrom(PROJECT_SMOOVE[idx % PROJECT_SMOOVE.length])}>
          <div class="thumb">
            <img src="${w.img}" alt="${w.title} preview" loading="lazy"
              onerror="this.onerror=null;this.src='${FALLBACK_IMG}';" />
          </div>
          <div class="body">
            <div class="title">${w.title}</div>
            <p class="desc">${w.desc}</p>

            <div class="meta">
              ${safeArr(w.tags).map(t => `<span class="badge2">${t}</span>`).join("")}
            </div>

            <div class="actions">
              <a class="btn soft sm" href="project.html?p=${encodeURIComponent(w.id)}">
                <i class="fa-solid fa-book-open"></i> Read more
              </a>

              ${w.live ? `<a class="btn primary sm" target="_blank" rel="noopener noreferrer" href="${w.live}">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> Live
              </a>` : ""}

              ${w.code ? `<a class="btn ghost sm" target="_blank" rel="noopener noreferrer" href="${w.code}">
                <i class="fa-brands fa-github"></i> Code
              </a>` : ""}
            </div>
          </div>
        </article>
      `).join("");
        }

        function renderServices() {
            const el = $("#servicesGrid");
            if (!el) return;
            el.innerHTML = services.map((s, idx) => `
        <article class="card reveal service-card" ${attrsFrom(SERVICE_SMOOVE[idx % SERVICE_SMOOVE.length])}>
          <div class="ic"><i class="fa-solid ${s.icon}"></i></div>
          <h3>${s.title}</h3>
          <p>${s.desc}</p>
        </article>
      `).join("");
        }

        function renderStack() {
            if ($("#coreTags")) $("#coreTags").innerHTML = stack.core.map(t => `<span class="tag">${t}</span>`).join("");
            if ($("#toolTags")) $("#toolTags").innerHTML = stack.tools.map(t => `<span class="tag">${t}</span>`).join("");
            if ($("#focusTags")) $("#focusTags").innerHTML = stack.focus.map(t => `<span class="tag">${t}</span>`).join("");
        }

        /* ==========================
           Testimonials
        ========================== */
        let tIndex = 0;
        function buildDots() {
            const wrap = $("#tDots");
            if (!wrap) return;
            wrap.innerHTML = testimonials.map((_, i) =>
                `<button class="t-dot ${i === tIndex ? "active" : ""}" aria-label="Go to testimonial ${i + 1}" data-i="${i}"></button>`
            ).join("");
            $$("#tDots .t-dot").forEach(btn => {
                btn.addEventListener("click", () => {
                    const i = Number(btn.getAttribute("data-i"));
                    if (Number.isFinite(i)) { tIndex = i; drawTestimonial(); }
                });
            });
        }
        function drawTestimonial() {
            const card = $("#tCard");
            if (!card || !testimonials.length) return;
            const t = testimonials[tIndex];
            card.innerHTML = `
        <div class="t-quoteIcon"><i class="fa-solid fa-quote-left"></i></div>
        <p class="q">“${t.quote}”</p>
        <div class="who">
          <div class="p"><img src="${t.img}" alt="${t.name}" loading="lazy" onerror="this.style.display='none'"></div>
          <div>
            <div class="n">${t.name}</div>
            <div class="r">${t.role}</div>
          </div>
        </div>
      `;
            buildDots();
        }
        function tNext() { if (!testimonials.length) return; tIndex = (tIndex + 1) % testimonials.length; drawTestimonial(); }
        function tPrev() { if (!testimonials.length) return; tIndex = (tIndex - 1 + testimonials.length) % testimonials.length; drawTestimonial(); }

        /* ==========================
           Reveal on scroll (with fallback)
        ========================== */
        function setupReveal() {
            const els = $$(".reveal");
            if (!els.length) return;

            if (!("IntersectionObserver" in window)) {
                forceShowAllReveal();
                return;
            }

            const io = new IntersectionObserver((entries) => {
                entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("show"); });
            }, { threshold: 0.12 });

            els.forEach(el => io.observe(el));

            // ✅ Safety: if after a short delay none show (rare mobile bugs), force show.
            setTimeout(() => {
                const anyShown = els.some(el => el.classList.contains("show"));
                if (!anyShown) forceShowAllReveal();
            }, 1200);
        }

        /* ==========================
           Theme toggle
        ========================== */
        function setupTheme() {
            const key = "sm_theme";
            const btn = $("#themeBtn");
            if (!btn) return;

            const apply = (mode) => {
                document.documentElement.setAttribute("data-theme", mode);
                btn.innerHTML = mode === "light"
                    ? '<i class="fa-solid fa-moon"></i>'
                    : '<i class="fa-solid fa-sun"></i>';
            };

            const saved = localStorage.getItem(key);
            if (saved) apply(saved);

            btn.addEventListener("click", () => {
                const cur = document.documentElement.getAttribute("data-theme") || "dark";
                const next = cur === "dark" ? "light" : "dark";
                localStorage.setItem(key, next);
                apply(next);
            });
        }

        /* ==========================
           Mobile nav (stronger for touch)
           ✅ Fix outside-click on mobile by using pointerdown.
        ========================== */
        function setupMobileNav() {
            const burger = $("#burger");
            const mnav = $("#mnav");
            const close = $("#mnavClose");
            if (!burger || !mnav) return;

            const open = () => mnav.setAttribute("aria-hidden", "false");
            const shut = () => mnav.setAttribute("aria-hidden", "true");

            burger.addEventListener("click", (e) => {
                e.stopPropagation();
                const openNow = mnav.getAttribute("aria-hidden") === "true";
                if (openNow) open(); else shut();
            });

            close?.addEventListener("click", shut);
            $$("#mnav a").forEach(a => a.addEventListener("click", shut));

            const onOutside = (e) => {
                const isOpen = mnav.getAttribute("aria-hidden") === "false";
                if (!isOpen) return;

                if (burger.contains(e.target)) return;
                if (!mnav.contains(e.target)) shut();
            };

            document.addEventListener("pointerdown", onOutside);
            document.addEventListener("keydown", (e) => { if (e.key === "Escape") shut(); });
        }

        /* ==========================
           Contact form (mailto)
        ========================== */
        function setupContact() {
            const form = $("#contactForm");
            const hint = $("#formHint");
            if (!form || !hint) return;

            form.addEventListener("submit", (e) => {
                e.preventDefault();
                const fd = new FormData(form);
                const name = String(fd.get("name") || "").trim();
                const email = String(fd.get("email") || "").trim();
                const topic = String(fd.get("topic") || "").trim();
                const msg = String(fd.get("message") || "").trim();

                if (!name || !email || !topic || !msg) {
                    hint.textContent = "Please fill all fields.";
                    return;
                }

                const subject = encodeURIComponent(`Project inquiry: ${topic}`);
                const body = encodeURIComponent(
                    `Name: ${name}\nEmail: ${email}\nTopic: ${topic}\n\nMessage:\n${msg}\n`
                );

                hint.textContent = "Opening your email app…";
                window.location.href = `mailto:info@simonmabur.tech?subject=${subject}&body=${body}`;
            });
        }

        /* ==========================
           Back to top
        ========================== */
        function setupBackToTop() {
            const btn = $("#backTopBtn");
            if (!btn) return;

            const onScroll = () => {
                const y = window.scrollY || document.documentElement.scrollTop || 0;
                if (y > 500) btn.classList.add("show");
                else btn.classList.remove("show");
            };

            btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
            window.addEventListener("scroll", onScroll, { passive: true });
            onScroll();
        }

        /* ==========================
           Active nav tracker
        ========================== */
        function setupActiveNav() {
            const links = Array.from(document.querySelectorAll(".links a"));
            const getIdFromLink = (a) => {
                const d = (a.getAttribute("data-link") || "").trim();
                if (d) return d;
                const href = (a.getAttribute("href") || "").trim();
                if (href.startsWith("#")) return href.slice(1);
                return "";
            };

            const sections = links.map(a => document.getElementById(getIdFromLink(a))).filter(Boolean);
            if (!links.length || !sections.length) return;

            const getPad = () =>
                parseInt(getComputedStyle(document.documentElement).getPropertyValue("--scroll-pad")) || 20;

            const setActive = (id) => links.forEach(a => a.classList.toggle("active", getIdFromLink(a) === id));

            let lockId = "";
            let lockUntil = 0;
            const lock = (id, ms = 1600) => { lockId = id; lockUntil = Date.now() + ms; setActive(id); };
            const isLocked = () => lockId && Date.now() < lockUntil;

            links.forEach(a => {
                a.addEventListener("click", (e) => {
                    const id = getIdFromLink(a);
                    const el = document.getElementById(id);
                    if (!id || !el) return;

                    e.preventDefault();
                    const pad = getPad();
                    const top = el.getBoundingClientRect().top + window.pageYOffset;
                    const targetY = Math.max(0, Math.floor(top - pad - 10));

                    lock(id);
                    window.scrollTo({ top: targetY, behavior: "smooth" });
                    history.replaceState(null, "", "#" + id);

                    const start = performance.now();
                    (function watch() {
                        const y = window.pageYOffset || 0;
                        if (Math.abs(y - targetY) <= 6 || performance.now() - start > 1800) {
                            lockId = "";
                            updateActiveFromScroll();
                            return;
                        }
                        requestAnimationFrame(watch);
                    })();
                });
            });

            let lastY = window.pageYOffset || 0;
            function updateActiveFromScroll() {
                if (isLocked()) return;

                const y = window.pageYOffset || document.documentElement.scrollTop || 0;
                const goingDown = y >= lastY;
                lastY = y;

                const pad = getPad();
                const bias = goingDown ? 10 : -10;
                const line = y + pad + bias;

                let current = sections[0].id;
                for (const s of sections) {
                    if (s.offsetTop <= line) current = s.id;
                    else break;
                }
                setActive(current);
            }

            window.addEventListener("scroll", updateActiveFromScroll, { passive: true });
            window.addEventListener("resize", updateActiveFromScroll, { passive: true });
            updateActiveFromScroll();
        }

        /* ==========================
           Welcome animation (unchanged)
        ========================== */
        function setupWelcome() {
            const overlay = document.getElementById("welcome");
            const stage = document.getElementById("welcomeStage");
            if (!overlay || !stage) return;

            const key = "sm_welcome_seen";
            if (localStorage.getItem(key) === "1") {
                overlay.setAttribute("aria-hidden", "true");
                return;
            }

            let burstTimer = null;
            let hideTimer = null;
            let rAF = null;

            const COLORS = ["#ffffff", "#ffd166", "#06b6d4", "#7c3aed", "#22c55e", "#ffffff", "#ffd166"];
            const TEXT = "Welcome :)";

            const cleanup = () => {
                if (burstTimer) clearTimeout(burstTimer);
                if (hideTimer) clearTimeout(hideTimer);
                window.removeEventListener("resize", onResize);
                overlay.removeEventListener("click", onClick);
            };

            const softHide = () => {
                overlay.classList.add("is-hiding");
                const dur = 720;
                setTimeout(() => {
                    overlay.setAttribute("aria-hidden", "true");
                    try { localStorage.setItem(key, "1"); } catch (e) { }
                    cleanup();
                }, dur);
            };

            function build() {
                stage.innerHTML = "";

                const word = document.createElement("div");
                word.className = "word";
                stage.appendChild(word);

                const cs = getComputedStyle(document.documentElement);
                const size = parseFloat(cs.getPropertyValue("--welcome-size")) || 44;
                const gap = parseFloat(cs.getPropertyValue("--welcome-gap")) || 6;

                const chars = [...TEXT];

                const maxW = Math.min(window.innerWidth || 360, 560);
                const idealW = chars.length * size + (chars.length - 1) * gap;
                const scale = Math.min(1, (maxW * 0.92) / idealW);

                word.style.transform = `translate(-10px, -10px) scale(${scale})`;
                word.style.transformOrigin = "center";

                const step = size + gap;
                const startX = -((chars.length - 1) * step) / 2;
                const radius = Math.max(70, Math.min(160, (size * 2.55) * scale));

                chars.forEach((ch, i) => {
                    const x = startX + i * step;
                    const wc = COLORS[i % COLORS.length];

                    const el = document.createElement("div");
                    el.className = "ch";
                    el.textContent = ch;
                    el.style.left = `${x}px`;
                    el.style.setProperty("--i", i);
                    el.style.setProperty("--wc", wc);
                    word.appendChild(el);

                    const fr = document.createElement("div");
                    fr.className = "frame";
                    fr.style.left = `${x}px`;
                    fr.style.top = `0px`;
                    fr.style.setProperty("--i", i);
                    fr.style.setProperty("--wc", wc);
                    word.appendChild(fr);

                    const count = 12;
                    for (let k = 0; k < count; k++) {
                        const p = document.createElement("div");
                        p.className = "p";
                        p.style.left = `${x}px`;
                        p.style.top = `0px`;
                        p.style.setProperty("--i", i);

                        const angle = (Math.PI * 2 * k) / count;
                        p.style.setProperty("--dx", `${Math.cos(angle) * radius}px`);
                        p.style.setProperty("--dy", `${Math.sin(angle) * radius}px`);
                        p.style.setProperty("--wc", wc);
                        word.appendChild(p);
                    }
                });
            }

            function burst() {
                const confettiPalette = ["#ffd166", "#06b6d4", "#7c3aed", "#22c55e", "#ffffff"];
                for (let i = 0; i < 42; i++) {
                    const c = document.createElement("div");
                    c.className = "confetti";
                    const ang = Math.random() * Math.PI * 2;
                    const dist = 90 + Math.random() * 190;
                    c.style.setProperty("--dx", `${Math.cos(ang) * dist}px`);
                    c.style.setProperty("--dy", `${Math.sin(ang) * dist}px`);
                    c.style.setProperty("--rot", `${Math.random() * 360}deg`);
                    c.style.setProperty("--conf", confettiPalette[i % confettiPalette.length]);
                    c.style.animationDelay = `${Math.random() * 120}ms`;
                    stage.appendChild(c);
                    c.addEventListener("animationend", () => c.remove(), { once: true });
                }
                for (let i = 0; i < 18; i++) {
                    const s = document.createElement("div");
                    s.className = "spark";
                    const ang = Math.random() * Math.PI * 2;
                    const dist = 70 + Math.random() * 160;
                    s.style.setProperty("--dx", `${Math.cos(ang) * dist}px`);
                    s.style.setProperty("--dy", `${Math.sin(ang) * dist}px`);
                    s.style.animationDelay = `${Math.random() * 120}ms`;
                    stage.appendChild(s);
                    s.addEventListener("animationend", () => s.remove(), { once: true });
                }
            }

            function onResize() { cancelAnimationFrame(rAF); rAF = requestAnimationFrame(build); }
            function onClick() { softHide(); }

            build();
            window.addEventListener("resize", onResize, { passive: true });
            burstTimer = setTimeout(burst, 4600);
            hideTimer = setTimeout(softHide, 6200);
            overlay.addEventListener("click", onClick, { once: true });
        }

        /* ==========================
           Network canvas (safe)
        ========================== */
        function startNetwork() {
            const canvas = document.getElementById("net");
            if (!canvas) return;
            const ctx = canvas.getContext("2d", { alpha: true });
            if (!ctx) return;

            let w = 0, h = 0;
            let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
            let nodes = [];
            let rafId = null;
            const cfg = { count: 62, speed: 0.42, linkDist: 175, nodeSize: [2.0, 4.2], linkWidth: 1.25 };

            function lerp(a, b, t) { return a + (b - a) * t; }
            function resize() {
                const rect = canvas.getBoundingClientRect();
                w = Math.floor(rect.width);
                h = Math.floor(rect.height);
                canvas.width = Math.floor(w * dpr);
                canvas.height = Math.floor(h * dpr);
                canvas.style.width = w + "px";
                canvas.style.height = h + "px";
                ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                nodes = Array.from({ length: cfg.count }, () => makeNode(true));
            }
            function makeNode(randomVel = false) {
                const r = lerp(cfg.nodeSize[0], cfg.nodeSize[1], Math.random());
                const angle = Math.random() * Math.PI * 2;
                const sp = cfg.speed * (0.6 + Math.random() * 1.2);
                const vx = randomVel ? Math.cos(angle) * sp : (Math.random() - 0.5) * sp;
                const vy = randomVel ? Math.sin(angle) * sp : (Math.random() - 0.5) * sp;
                return { x: Math.random() * w, y: Math.random() * h, vx, vy, r };
            }
            function getTextColor() {
                const cs = getComputedStyle(document.documentElement);
                return cs.getPropertyValue("--text").trim() || "#eef2ff";
            }
            function withAlpha(color, alpha) {
                if (color.startsWith("#") && (color.length === 7 || color.length === 4)) {
                    let r, g, b;
                    if (color.length === 4) {
                        r = parseInt(color[1] + color[1], 16);
                        g = parseInt(color[2] + color[2], 16);
                        b = parseInt(color[3] + color[3], 16);
                    } else {
                        r = parseInt(color.slice(1, 3), 16);
                        g = parseInt(color.slice(3, 5), 16);
                        b = parseInt(color.slice(5, 7), 16);
                    }
                    return `rgba(${r},${g},${b},${alpha})`;
                }
                return `rgba(255,255,255,${alpha})`;
            }

            const mouse = { x: -9999, y: -9999, active: false };
            const hero = document.querySelector(".hero");
            hero?.addEventListener("mousemove", (e) => {
                const r = hero.getBoundingClientRect();
                mouse.x = e.clientX - r.left;
                mouse.y = e.clientY - r.top;
                mouse.active = true;
            }, { passive: true });
            hero?.addEventListener("mouseleave", () => { mouse.active = false; }, { passive: true });

            function step() {
                const text = getTextColor();
                ctx.clearRect(0, 0, w, h);

                for (const n of nodes) {
                    if (mouse.active) {
                        const dx = mouse.x - n.x;
                        const dy = mouse.y - n.y;
                        const dist = Math.hypot(dx, dy);
                        if (dist < 210 && dist > 0.1) {
                            n.vx += (dx / dist) * 0.0032;
                            n.vy += (dy / dist) * 0.0032;
                        }
                    }
                    n.x += n.vx; n.y += n.vy;
                    n.vx *= 0.994; n.vy *= 0.994;
                    if (n.x < 0 || n.x > w) n.vx *= -1;
                    if (n.y < 0 || n.y > h) n.vy *= -1;
                    n.x = Math.max(0, Math.min(w, n.x));
                    n.y = Math.max(0, Math.min(h, n.y));
                }

                for (let i = 0; i < nodes.length; i++) {
                    for (let j = i + 1; j < nodes.length; j++) {
                        const a = nodes[i], b = nodes[j];
                        const dx = a.x - b.x, dy = a.y - b.y;
                        const dist = Math.hypot(dx, dy);
                        if (dist < cfg.linkDist) {
                            const alpha = (1 - dist / cfg.linkDist) * 0.34;
                            ctx.strokeStyle = withAlpha(text, alpha);
                            ctx.lineWidth = cfg.linkWidth;
                            ctx.beginPath();
                            ctx.moveTo(a.x, a.y);
                            ctx.lineTo(b.x, b.y);
                            ctx.stroke();
                        }
                    }
                }

                for (const n of nodes) {
                    ctx.fillStyle = withAlpha(text, 0.92);
                    ctx.beginPath();
                    ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
                    ctx.fill();
                }

                rafId = requestAnimationFrame(step);
            }

            const prefersReduced = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
            const ro = new ResizeObserver(resize);
            ro.observe(canvas);
            resize();
            if (!prefersReduced) step();
            return () => { if (rafId) cancelAnimationFrame(rafId); ro.disconnect(); };
        }

        /* ==========================
           Apply effects
        ========================== */
        function applyHeroMiniCardEffects() {
            const minis = $$(".hero-mini");
            minis.forEach((el, i) => {
                const fx = HERO_MINICARD_SMOOVE[i % HERO_MINICARD_SMOOVE.length];
                setAttrs(el, fx);
                el.classList.add("mini-anim");
            });
        }
        function applyStackEffects() {
            const cards = $$(".stack-anim");
            cards.forEach((el, i) => {
                const fx = STACK_SMOOVE[i % STACK_SMOOVE.length];
                setAttrs(el, fx);
            });
        }
        function applyTestimonialEffects() {
            const aside = $(".t-anim-aside");
            const main = $(".t-anim-main");
            setAttrs(aside, TESTIMONIAL_SMOOVE[0]);
            setAttrs(main, TESTIMONIAL_SMOOVE[1]);
        }
        function applyContactEffects() {
            const shell = $(".c-anim-shell");
            const form = $(".c-anim-form");
            setAttrs(shell, CONTACT_SMOOVE[0]);
            setAttrs(form, CONTACT_SMOOVE[1]);
        }
        function applyFooterEffects() {
            const cols = $$(".foot-anim");
            cols.forEach((el, i) => {
                const fx = FOOTER_SMOOVE[i % FOOTER_SMOOVE.length];
                setAttrs(el, fx);
            });
        }

        /* ==========================
           Smoove init
        ========================== */
        function initSmoove() {
            const jq = window.jQuery;
            if (!jq || !jq.fn || !jq.fn.smoove) return;

            jq(".service-card").smoove({ offset: "40%" });
            jq(".project-card").smoove({ offset: "40%" });

            jq(".kpi-anim").smoove({ offset: "42%" });
            jq(".mini-anim").smoove({ offset: "45%" });
            jq(".stack-anim").smoove({ offset: "40%" });
            jq(".t-anim-aside, .t-anim-main").smoove({ offset: "38%" });
            jq(".c-anim-shell, .c-anim-form").smoove({ offset: "40%" });
            jq(".foot-anim").smoove({ offset: "45%" });
        }

        /* ==========================
           Init
        ========================== */
        (function init() {
            const yearEl = $("#year");
            if (yearEl) yearEl.textContent = new Date().getFullYear();

            renderKPIs();
            renderWork();
            renderServices();
            renderStack();

            drawTestimonial();
            $("#tNext")?.addEventListener("click", tNext);
            $("#tPrev")?.addEventListener("click", tPrev);
            if ($("#tNext") && $("#tPrev") && testimonials.length) setInterval(tNext, 7000);

            setupReveal();
            setupTheme();
            setupMobileNav();
            setupContact();
            setupBackToTop();
            setupActiveNav();
            setupWelcome();
            startNetwork();

            applyHeroMiniCardEffects();
            applyStackEffects();
            applyTestimonialEffects();
            applyContactEffects();
            applyFooterEffects();
            initSmoove();
        })();
     