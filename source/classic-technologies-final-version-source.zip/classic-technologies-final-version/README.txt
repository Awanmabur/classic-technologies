Classic Technologies Final Website Package

Files:
- index.html: final one-page website with embedded CSS/JS and embedded logo.
- assets/classic-technologies-logo.png: logo copy.
- source-data/portfolio-projects-and-services.json: project and service data extracted from the uploaded portfolio.

How to host:
1. Upload the whole folder to your hosting.
2. Set index.html as the homepage.
3. Update phone/email/social links if needed.
4. Connect the contact form to EmailJS, Formspree, Firebase, or your backend.

Contact used in this version:
- Email: info@junubclassic.org
- Phone/WhatsApp: +256 781 977 217
